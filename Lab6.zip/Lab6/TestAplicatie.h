#pragma once
void test();

