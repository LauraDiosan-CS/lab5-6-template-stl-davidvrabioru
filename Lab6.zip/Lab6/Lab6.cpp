
#include <iostream>
#include "TestAplicatie.h"
using namespace std;
int main()
{

    cout << "start... \n";
    test();
    cout << "Succes! ";
}

